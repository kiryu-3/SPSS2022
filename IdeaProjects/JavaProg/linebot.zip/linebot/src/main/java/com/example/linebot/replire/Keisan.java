package com.example.linebot.replire;

import com.linecorp.bot.model.event.MessageEvent;
import com.linecorp.bot.model.event.message.TextMessageContent;
import com.linecorp.bot.model.message.Message;
import com.linecorp.bot.model.message.TextMessage;

public class Keisan {
    private MessageEvent<TextMessageContent> event;
    Kigou_Reigai kigou_reigai =new Kigou_Reigai();
    Kyousei_Replier kyousei_replier = new Kyousei_Replier();
    private float n,m;
    private String kigou;

    public Message enzan(float n,float m,String kigou){
        this.n=n;
        this.m=m;
        this.kigou=kigou;

        switch (kigou){
            case "+":
                return new TextMessage(Float.toString(n+m));

            case "-":
                return new TextMessage(Float.toString(n-m));

            case "×":
                return new TextMessage(Float.toString(n*m));

            case "÷":
                if(m==0){
                    return new TextMessage("答えは存在しません");
                } else {
                    return new TextMessage(Float.toString(n/m));
                }

            case "強制終了":
                return kyousei_replier.reply();

            default:
                return kigou_reigai.reply();
        }
    }



}
