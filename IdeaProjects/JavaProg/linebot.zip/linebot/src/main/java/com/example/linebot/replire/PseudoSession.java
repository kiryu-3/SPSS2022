package com.example.linebot.replire;

import java.util.HashMap;
import java.util.Map;

public class PseudoSession {
    private static Map<String,Status> statusMap = new HashMap<>();

    public static Status getStatus(String userId) {
        return PseudoSession.statusMap.get(userId);
    }

    public static void putStatus(String userId, Status status) {
        PseudoSession.statusMap.put(userId, status);
    }

    public static String readContext(String userId) {
        return PseudoSession.statusMap.get(userId).getContext();
    }

    public static double read_n(String userId) {
        return PseudoSession.statusMap.get(userId).getn();
    }

    public static double read_m(String userId) {
        return PseudoSession.statusMap.get(userId).getm();
    }

    public static void updateContext(String userId, String context) {
        Status newStatus = PseudoSession.statusMap.get(userId);
        newStatus.setContext(context);
        PseudoSession.statusMap.put(userId, newStatus);
    }

    public static void updatePlace_n(String userId, double n) {
        Status newStatus = PseudoSession.statusMap.get(userId);
        newStatus.setn(n);
        PseudoSession.statusMap.put(userId, newStatus);
    }

    public static void updatePlace_m(String userId, double m) {
        Status newStatus = PseudoSession.statusMap.get(userId);
        newStatus.setn(m);
        PseudoSession.statusMap.put(userId, newStatus);
    }




}
