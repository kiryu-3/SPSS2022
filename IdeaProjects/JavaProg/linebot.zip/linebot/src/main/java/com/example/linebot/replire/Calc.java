package com.example.linebot.replire;

import java.util.Map;
import java.util.Scanner;
import com.linecorp.bot.model.event.MessageEvent;
import com.linecorp.bot.model.event.message.TextMessageContent;
import com.linecorp.bot.model.message.Message;
import com.linecorp.bot.model.message.TextMessage;


public class Calc {
    private double n1,n2,ans;
    private String context="";
    private String kigou;
    private MessageEvent<TextMessageContent> event;
    Kigou_Reigai reigai =new Kigou_Reigai();
    Scanner input = new Scanner(System.in);

    public void input1(){
        try{
            this.n1=input.nextDouble();
        }catch (IndexOutOfBoundsException e){
            reigai.reply();
            this.n1=input.nextDouble();
        }
    }

    public void input2(){
        try{
            this.n2=input.nextDouble();
        }catch (IndexOutOfBoundsException e){
            reigai.reply();
            this.n2=input.nextDouble();
        }
    }

    public double getN1(){
        return n1;
    }

    public double getN2(){
        return n2;
    }

    public void setcontext(String context){
        this.context=context;
    }

    public String getContext(){
        return context;
    }

    public Message enzan(double n1, double n2){

        this.kigou=input.nextLine();
        if(kigou.equals("+")){
            ans=n1+n2;
            return new TextMessage(String.valueOf(ans));
        }else if(kigou.equals("-")){
            ans=n1-n2;
            return new TextMessage(String.valueOf(ans));
        }else if(kigou.equals("×")){
            ans=n1*n2;
            return new TextMessage(String.valueOf(ans));
        }else if(kigou.equals("÷")){
            if(n2==0){
                return new TextMessage("割れない");
            }else{
                ans=n1/n2;
                return new TextMessage(String.valueOf(ans));
            }
        }else{
            reigai.reply();
            this.kigou=input.nextLine();
        }
        return new TextMessage("問題あり");
    }
}
