package com.example.linebot.replire;

import com.linecorp.bot.model.message.Message;

public interface Replier {
    // 返信用クラスが必ず実装するメソッド
    Message reply();

}
