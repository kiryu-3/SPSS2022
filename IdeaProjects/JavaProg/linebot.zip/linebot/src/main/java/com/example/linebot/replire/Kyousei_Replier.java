package com.example.linebot.replire;

import com.linecorp.bot.model.event.MessageEvent;
import com.linecorp.bot.model.event.message.TextMessageContent;
import com.linecorp.bot.model.message.Message;
import com.linecorp.bot.model.message.TextMessage;

public class Kyousei_Replier implements Replier{
    private MessageEvent<TextMessageContent> event;

    @Override
    public Message reply() {
        return new TextMessage("強制終了");
    }
}
