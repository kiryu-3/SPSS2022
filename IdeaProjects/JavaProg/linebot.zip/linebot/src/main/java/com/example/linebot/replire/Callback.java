package com.example.linebot.replire;

import com.example.linebot.replire.Follow;
import com.linecorp.bot.model.event.FollowEvent;
import com.linecorp.bot.model.message.Message;
import com.linecorp.bot.spring.boot.annotation.EventMapping;
import com.linecorp.bot.spring.boot.annotation.LineMessageHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.linecorp.bot.model.event.message.TextMessageContent;
import com.linecorp.bot.model.event.MessageEvent;
import com.example.linebot.replire.Parrot;
import com.example.linebot.replire.Greet;
import com.example.linebot.replire.Omikuji;

import com.linecorp.bot.client.LineBlobClient;
import com.linecorp.bot.client.MessageContentResponse;
import com.linecorp.bot.model.event.message.ImageMessageContent;
import com.linecorp.bot.model.message.TextMessage;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import java.util.ArrayList;


@LineMessageHandler
public class Callback {

    private static final Logger log = LoggerFactory.getLogger(Callback.class);
    private LineBlobClient client;

    private ArrayList<Float> number =new ArrayList<>();
    private int flag=0;


    @Autowired
    public Callback(LineBlobClient client) {
        this.client = client;
    }


    // フォローイベントに対応する
    @EventMapping
    public Message handleFollow(FollowEvent event) {
        // 実際はこのタイミングでフォロワーのユーザIDをデータベースにに格納しておくなど
        Follow follow = new Follow(event);
        return follow.reply();
    }

    @EventMapping
    public Message handleMessage(MessageEvent<TextMessageContent> event) {
        TextMessageContent tmc = event.getMessage();
        String text = tmc.getText();
        Number_Reigai n_reigai = new Number_Reigai();
        Kyousei_Replier kyousei = new Kyousei_Replier();
        Keisan keisan = new Keisan();

        if(Objects.equals(text, "やあ") && flag==0) {
            Greet greet = new Greet();
            return greet.reply();
        } else if(Objects.equals(text, "おみくじ") && flag==0) {
            Omikuji omikuji = new Omikuji();
            return omikuji.reply();
        } else if (Objects.equals(text, "計算") && flag==0) {
            this.flag=1;
            return new TextMessage("数字を入力してね(1回目)\n途中でやめたい場合には\n「強制終了」と入力してね");
        } else if(flag==1 && !text.equals("強制終了")){
            try{
                number.add(0,Float.valueOf(text));
                this.flag=2;
                return new TextMessage("数字を入力してね(2回目)");
            }catch (NumberFormatException e){
                return n_reigai.reply();
            }

        } else if(flag==1 && text.equals("強制終了")){
            this.flag=0;
            return kyousei.reply();
        }
        else if (flag==2 && !text.equals("強制終了")) {
            try{
                number.add(1,Float.valueOf(text));
                this.flag=3;
                return new TextMessage("どんな計算したい?(+,-,×,÷)");
            } catch (NumberFormatException e){
                return n_reigai.reply();
            }

        } else if (flag==2 && text.equals("強制終了")) {
            this.flag=0;
            return kyousei.reply();
        } else if (flag==3) {
            this.flag=0;
            return keisan.enzan(number.get(0),number.get(1),text);
        } else {
            Parrot parrot = new Parrot(event);
            return parrot.reply();
        }
    }

    // 画像のメッセージイベントに対応する
    @EventMapping
    public Message handleImg(MessageEvent<ImageMessageContent> event) {
        // ①画像メッセージのidを取得する
        String msgId = event.getMessage().getId();
        Optional<String> opt = Optional.empty();
        try {
            // ②画像メッセージのidを使って MessageContentResponse を取得する
            MessageContentResponse resp = client.getMessageContent(msgId).get();
            log.info("get content{}:", resp);
            // ③ MessageContentResponse からファイルをローカルに保存する
            // ※LINEでは、どの解像度で写真を送っても、サーバ側でjpgファイルに変換される
            opt = makeTmpFile(resp, ".jpg");
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        // ④ ファイルが保存できたことが確認できるように、ローカルのファイルパスをコールバックする
        // 運用ではファイルパスを表示することは避けましょう
        String path = opt.orElseGet(() -> "ファイル書き込みNG");
        return new TextMessage(path);
    }

    // MessageContentResponseの中のバイト入力ストリームを、拡張子を指定してファイルに書き込む。
    // また、保存先のファイルパスをOptional型で返す。
    private Optional<String> makeTmpFile(MessageContentResponse resp, String extension) {
        // tmpディレクトリに一時的に格納して、ファイルパスを返す
        try (InputStream is = resp.getStream()) {
            Path tmpFilePath = Files.createTempFile("linebot", extension);
            Files.copy(is, tmpFilePath, StandardCopyOption.REPLACE_EXISTING);
            return Optional.ofNullable(tmpFilePath.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }



}
