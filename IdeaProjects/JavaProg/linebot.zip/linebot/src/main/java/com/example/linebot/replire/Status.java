package com.example.linebot.replire;

public class Status {
    private String context = "0";//ステータス
    private double n = 0;
    private double m = 0;

    public String getContext() {
        return context;
    }
    public void setContext(String context) {
        this.context = context;
    }

    public double getn() {
        return n;
    }
    public void setn(double n) {
        this.n = n;
    }

    public double getm(){
        return m;
    }

    public void setm(double m){
        this.m=m;
    }
}
